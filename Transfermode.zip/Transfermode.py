bl_info = {
    "name": "Trans Mode",
    "author": "Redwolfen",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Panel",
    "description": "switch Objects",
    "warning": "",
    "doc_url": "",
    "category": "object mesh",
}    

import bpy

from bpy.types import Panel

class TransferPanel(bpy.types.Panel):
    bl_label = "Trans Mode"
    bl_idname = "OBJECT_PT_transfer_mode"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Trans Mode"

    def draw(self, context):
        layout = self.layout
        obj = context.object

        layout.prop(obj, "transfer_mode", text="Mode")
        layout.prop(obj, "transfer_keep_vertex_order", text="Keep Vertex Order")
        layout.operator("object.transfer_mode")
        
def register():
    bpy.utils.register_class(TransferPanel)

def unregister():
    bpy.utils.unregister_class(TransferPanel)

if __name__ == "__main__":
    register()